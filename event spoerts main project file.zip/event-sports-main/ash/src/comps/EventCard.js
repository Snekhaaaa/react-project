// import * as React from 'react';
// import Accordion from '@mui/material/Accordion';
// import AccordionSummary from '@mui/material/AccordionSummary';
// import AccordionDetails from '@mui/material/AccordionDetails';
// import Typography from '@mui/material/Typography';
// import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

// export default function BasicAccordion({name}) {
//   return (
//     <div>
//       <Accordion >
//         <AccordionSummary
//           expandIcon={<ExpandMoreIcon />}
//           aria-controls="panel1a-content"
//           id="panel1a-header"
//         >
//           <Typography>{name}</Typography>
//         </AccordionSummary>
//         <AccordionDetails>
//           <Typography>
//            01    :   Cricket   ||   12-11-2023      ~      Lords.
//           </Typography>
//           <Typography>
//            02   :   FootBall    ||  12-11-2023     ~     Santiago Bernabeu.
//           </Typography>
//           <Typography>
//            03    :   Kabbadi     ||   12-11-2023      ~    Tamilnadu.
//           </Typography>
//           <Typography>
//            04    :   BasketBall   ||  12-11-2023     ~     Madison Square Garden.
//           </Typography>
//           <Typography>
//            05    :   Gymnastics   ||  12-11-2023   ~     Krishna Hall.
//           </Typography>
//         </AccordionDetails>
//       </Accordion>
//     </div>
//   );
// }